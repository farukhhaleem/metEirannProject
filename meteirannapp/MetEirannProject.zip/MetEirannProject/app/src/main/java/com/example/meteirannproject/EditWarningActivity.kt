package com.example.meteirannproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class EditWarningActivity : AppCompatActivity() {
    //FARUKH HALEEM
    //16648
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_warning)


        val saveButton = findViewById<Button>(R.id.edit_save_button)
        val cancelButton = findViewById<Button>(R.id.edit_cancel_button)
        val deleteButton = findViewById<Button>(R.id.edit_delete_button)
        //get the index of the warning
        val position = intent.getIntExtra("positionID", 0)

        //update warning and send back to warning page
        saveButton.setOnClickListener {
            val areaText = findViewById<TextView>(R.id.edit_area_text)
            val levelText = findViewById<TextView>(R.id.edit_level_text)
            val typeText = findViewById<TextView>(R.id.edit_type_text)
            WarningAdapter.warningListData.area[position] = areaText.text.toString()
            WarningAdapter.warningListData.level[position] = levelText.text.toString()
            WarningAdapter.warningListData.type[position] = typeText.text.toString()
            val intent = Intent(this, WarningActivity::class.java)
            startActivity(intent)
        }

        //delete button, delete the warning
        deleteButton.setOnClickListener {
            WarningAdapter.warningListData.area.removeAt(position)
            val intent = Intent(this, WarningActivity::class.java)
            startActivity(intent)
        }

        //cancel button
        cancelButton.setOnClickListener {
            //go back to warning activity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}
