package com.example.meteirannproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_warning.*

class WarningActivity : AppCompatActivity() {
    //FARUKH HALEEM
    //16648
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_warning)

        //set the adapter for warning recycler list to warningadapter.kt
        recyclerView_warning.layoutManager = LinearLayoutManager(this)
        recyclerView_warning.adapter= WarningAdapter()
    }
}
