package com.example.meteirannproject

import android.content.Context
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    //FARUKH HALEEM
    //16648
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listView = findViewById<ListView>(R.id.main_listview)
        listView.adapter = MyCustomAdapter(this)
    }

    //open the warnings activity
    fun showWarnings(view: View) {
        val intent = Intent(this, WarningActivity::class.java)
        // start your next activity
        startActivity(intent)
    }

    //open the add warning activyity
    fun showAddWarning(view: View) {
        val intent = Intent(this, AddWarningActivity::class.java)
        // start your next activity
        startActivity(intent)
    }

    //this is the adapter for the 7 day list
    private class MyCustomAdapter(context: Context) : BaseAdapter() {
        //day
        private val days = arrayListOf<String>(
            "Day",
            "Today",
            "Tomorrow",
            "wednesday",
            "thursday",
            "friday",
            "saturday",
            "sunday"
        )
        //weather
        private val weather = arrayListOf<String>(
            "Weather",
            "rainy",
            "cloudy",
            "cloudy",
            "cloudy",
            "cloudy",
            "sunny",
            "sunny"
        )
        //temp
        private val temp = arrayListOf<String>(
            "°C",
            "11",
            "15",
            "9",
            "8",
            "7",
            "12",
            "6"
        )
        //windspeed
        private val windspeed = arrayListOf<String>(
            "Wind Km/h",
            "25",
            "33",
            "13",
            "13",
            "10",
            "32",
            "25"
        )
        //warning
        private val warning = arrayListOf<String>(
            "Warning",
            "green",
            "green",
            "green",
            "green",
            "green",
            "green",
            "green"
        )
        private val mContext: Context

        init {
            mContext = context
        }

        //resoibsivle for how many rows
        override fun getCount(): Int {
            return days.size
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getItem(position: Int): Any {
            return "TEST STRING"
        }

        //responsible for rendering out each rouw
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val layoutInflater = LayoutInflater.from(mContext)
            val rowMain = layoutInflater.inflate(R.layout.row_main, parent, false)

            //set the value for each row
            val daysText = rowMain.findViewById<TextView>(R.id.dayTextView)
            daysText.text = days.get(position)

            val weatherText = rowMain.findViewById<TextView>(R.id.weatherTextView)
            weatherText.text = weather.get(position)

            val tempText = rowMain.findViewById<TextView>(R.id.tempTextView)
            tempText.text = temp.get(position)

            val windSpeedText = rowMain.findViewById<TextView>(R.id.windSpeedTextView)
            windSpeedText.text = windspeed.get(position)

            val warningText = rowMain.findViewById<TextView>(R.id.warningTextView)
            warningText.text = warning.get(position)

            return rowMain
        }

    }


}
