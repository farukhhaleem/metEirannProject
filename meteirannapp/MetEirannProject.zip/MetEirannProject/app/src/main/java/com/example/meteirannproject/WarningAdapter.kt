package com.example.meteirannproject

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.warning_row.view.*

class WarningAdapter : RecyclerView.Adapter<CustomViewHolder>() {
    //FARUKH HALEEM
    //16648
    //this object contains the content of the recycler list
    companion object warningListData {
        var area = mutableListOf<String>("Dublin")
        var level = mutableListOf<String>("Yellow")
        var type = mutableListOf<String>("All")
    }

    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) {
        //set the value for each row based on companion object
        holder.view.warning_area_text?.text = area.get(position)
        holder.view.warning_level_text?.text = level.get(position)
        holder.view.warning_type_text?.text = type.get(position)
        holder?.index = position
    }

    //number of items
    override fun getItemCount(): Int {
        return area.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val callForRow = layoutInflater.inflate(R.layout.warning_row, parent, false)


        return CustomViewHolder(callForRow, 0)
    }
}

class CustomViewHolder(val view: View, var index: Int?) : RecyclerView.ViewHolder(view) {
    init {
        //when the row is clicked it will take to Edit Warning Activity
        view.setOnClickListener {
            val intent = Intent(view.context, EditWarningActivity::class.java)
            intent.putExtra("positionID", index)
            view.context.startActivity(intent)
        }
    }
}