package com.example.meteirannproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class AddWarningActivity : AppCompatActivity() {
    //FARUKH HALEEM
    //16648
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_warning)

        val addButton = findViewById<Button>(R.id.add_add_button)
        val cancelButton = findViewById<Button>(R.id.add_cancel_button)

        //when the add button is clicked, an new warning should be added to the warning list
        addButton.setOnClickListener {
            val areaText = findViewById<TextView>(R.id.add_area_text)
            val levelText = findViewById<TextView>(R.id.add_level_text)
            val typeText = findViewById<TextView>(R.id.add_type_text)
            WarningAdapter.warningListData.area.add(areaText.text.toString())
            WarningAdapter.warningListData.level.add(levelText.text.toString())
            WarningAdapter.warningListData.type.add(typeText.text.toString())
            val intent = Intent(this, WarningActivity::class.java)
            startActivity(intent)
        }

        //cancel button
        cancelButton.setOnClickListener {
            //go to home
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }
}
